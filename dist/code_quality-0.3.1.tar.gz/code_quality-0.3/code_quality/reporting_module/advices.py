
advices = {
    "Readability Score": "Adding comments, giving helpful variable names, consistent casing may help with readability.",
    "Document Size Score": "Extremely large documents may deter people from reading, very small document may be wasteful.",
    "Redundancy Check Score": "Divide large pieces of code into small reusable pieces of code.",
    "Function size score": "Keep functions small. Large functions get unmanageable over time."
}

# May add more checks and advices in future
